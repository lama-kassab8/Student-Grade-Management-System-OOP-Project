import json
from course import Course
from student import Student

class Manager:
    def __init__(self, students=[]):
        self.students= students if students else []

    def load_students(self):
        try:
            with open("students.json", "r") as f:
                students= json.load(f)
            return students
        except (FileNotFoundError, json.JSONDecodeError):
            print("There was a problem loading the data.")
            return []
        
    def save_students(self, students):
        try:
            with open("students.json", "w") as f:
                json.dump(students, f, indent=4)
        except IOError:
            print("There was a problem saving the changes.")

    def load_courses(self):
        try:
            with open("courses.json", "r") as f:
                courses= json.load(f)
            return courses
        except (FileNotFoundError, json.JSONDecodeError):
            print("There was a problem loading the data.")
            return []
        
    def save_courses(self, courses):
        try:
            with open("courses.json", "w") as f:
                json.dump(courses, f, indent=4)
        except IOError:
            print("There was a problem saving the changes.")



    def add_student(self, student):
        students= self.load_students()
        if isinstance(student, Student):
            try:
                students.append({
                    'name': student.name,
                    'email': student.email,
                    'id': student.id,
                    'courses': student._courses,
                    'password': student.__password
                })
                self.save_students(students)
            except IOError:
                print("There was an error while adding the student.")
        else:
            print("You can only add Student instances.")

    
    def remove_student(self):
        remove_id= input("What's the ID for the person you want to remove? ")

        students= self.load_students()

        found= False

        for student in students:
            if student['id'] == remove_id:
                students.remove(student)
                found= True
                break

        if found:
            self.save_students(students)
            print(f"Student with ID {remove_id} has been removed.")

        else:
            print("Student not found.")


    def add_course(self,course):
        courses= self.load_courses()
        if isinstance(course, Course):
            try:
                courses.append({
                    'name': course.name,
                    'code': course.code,
                    'grade': course._grade,
                    'credits': course.credits
                })
                self.save_courses(courses)
            except IOError:
                print("There was a problem while adding the course.")
        else:
            print("You can only add Course instances.")

    def remove_course(self):
        remove_course= input("What's the code for the course you want to remove? \n")

        courses= self.load_courses()
        found= False

        for course in courses:
            if course['code']== remove_course:
                courses.remove(course)
                self.save_courses(courses)
                print(f"The course {course['name']} has been removed.")
                found= True
                break

        if not found:
            print("The course you typed is not inlisted in the courses.")


    def enroll(self):
        student_id= input("Enter the ID of the student you want to enroll: \n")
        course_code= input("Enter the code of the course you want to enroll the student in? \n")

        students= self.load_students()
        courses= self.load_courses()

        course_name= None
        for course in courses:
            if course['code'] ==course_code:
                course_name= course['name']
                break
        
        if not course_name:
            print("The course you typed is not found.")
            return

        student_name= None
        for student in students:
            if student['id']==student_id:
                student_name= student['name']
                break
        if not student_name:
            print("The student whose id you typed is not found.")
            return

        for student in students:
            if student['id'] == student_id:
                student['courses'].append(course_code)
                self.save_students(students)
                print(f"{student_name} has been enrolled in {course_name}.")
                break
        

    def drop_course(self):
        student_id= input("Enter the ID of the student you want to drop from the course? \n")
        course_code= input("Enter the code for the course you want the student to drop out of? \n")

        students= self.load_students()
        courses= self.load_courses()

        student_name= None
        for student in students:
            if student['id']==student_id:
                student_name= student['name']
                break
        if not student_name:
            print("The student whose id you typed is not found.")
            return

        course_name= None
        for course in courses:
            if course['code'] ==course_code:
                course_name= course['name']
                break
        
        if not course_name:
            print("The course you typed is not found.")
            return
        
        for student in students:
            if student['id']== student_id:
                if course_code in student['courses']:
                    student['courses'].remove(course_code)
                    self.save_students(students)
                    print(f"{student_name} dropped {course_name}.")
                else:
                    print(f"{student_name} is not enrolled in {course_name}.")
                return

    def list_students_info(self):
        students= self.load_students()
        courses= self.load_courses()

        for student in students:
            course_names = []
            for code in student['courses']:
                course = next((c for c in courses if c['code'] == code), None)
                if course:
                    course_names.append(course['name'])
            print(f"- Name: {student['name']}, email: {student['email']}, ID: {student['id']}, Enrolled Courses: {course_names}.")

    def list_courses_info(self):
        courses= self.load_courses()
        print("Courses offered: \n")
        for course in courses:
            
            print(f"Name: {course['name']}, Code: {course['code']}, Credits: {course['credits']}")