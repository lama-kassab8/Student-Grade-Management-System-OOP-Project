class Course:

    def __init__(self, name, code, grade, credits):
        self.name= name
        self.code= code
        self._grade= grade
        self.credits= credits

    @staticmethod
    def validate_grade(grade):
        if grade in range (0, 101):
            return True
        return False
    
    @property
    def grade(self):
        return self._grade
    
    @ grade.setter
    def grade(self, grade):
        if Course.validate_grade(grade):
            self._grade= grade
        else:
            raise ValueError("Invalid grade. The grade should be anywhere from 0 till 100.")
   
    
    def pass_fail(self):
        if  0 <= self.grade <= 100:
            print("Pass")
        else:
            print("Fail")