import re

class Student:
    def __init__(self, name, email,id, courses, password):
        self.name= name
        self._email= email
        self.id= id
        self._courses= courses
        self.__password= password

    @ property
    def gpa(self):
        if not self._courses:
            return 0
        total= sum(self._courses.values())
        return total/ len(self._courses)

    @ staticmethod
    def validate_email(email):
        pattern= r'^[\w\.-]+@[\w\.-]+\.\w+$'
        return re.match(pattern, email) is not None
        
    @ property
    def email(self):
        return self._email
    @ email.setter
    def email(self, new_email):
        if Student.validate_email(new_email):
            self._email= new_email
        else:
            raise ValueError("Invalid email format.")
        

    @staticmethod
    def validate_password(password):
        if (len(password) >= 6 
        and any(char.isupper() for char in password)
        and any(char.isdigit() for char in password)):
            return True
        print("Your password must be no less than 6 characters long and has at least one uppercase letter and one number.")
        return False
    
    @property
    def password(self):
        return self.__password
    
    @ password.setter
    def password(self, password):
        if Student.validate_password(password):
            self.__password= password
        else:
            raise ValueError("Invalid password format.")
