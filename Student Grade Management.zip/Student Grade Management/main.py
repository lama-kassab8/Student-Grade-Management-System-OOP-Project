from models.course import Course
from models.student import Student
from models.manager import Manager

manager= Manager()

def main():
    while True:
        print("\n MENU")
        print("1. List all students")
        print("2. Add a student")
        print("3. Remove a student")
        print("4. List all courses")
        print("5. Add a course")
        print("6. Remove a course")
        print("7. Enroll a student in a course")
        print("8. Drop a course for a student")
        print("9. Exit")

        try:
            choice = int(input("Choose an option: "))
        except ValueError:
            print("You can only type the number of the option you want to choose.")

        if choice == "1":
            manager.list_students_info()
        elif choice == "2":
            manager.add_student()
        elif choice == "3":
            manager.remove_student()
        elif choice == "4":
            manager.list_courses_info()
        elif choice == "5":
            manager.add_course()
        elif choice == "6":
            manager.remove_course()
        elif choice == "7":
            manager.enroll()
        elif choice == "8":
            manager.drop_course()
        elif choice == "9":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Try again.")

if __name__=="__main__":
    main()